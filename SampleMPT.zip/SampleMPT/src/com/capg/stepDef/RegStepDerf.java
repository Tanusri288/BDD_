package com.capg.stepDef;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.LoginPOM;
import com.capg.pom.RegistrationPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegStepDerf {

	WebDriver driver;
	private RegistrationPOM regpom;

	@Given("^user is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		driver = LoginPOM.getWebDriver();
		String url = "C:\\BDD-workspace-sts\\SampleMPT\\html\\registration.html";
		driver.get(url);
		regpom = new RegistrationPOM(driver);
	}

	@When("^User enter valid details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_enter_valid_details(String fullName, String email, String phone, String subject, String paper, String authors, String company, String designation) throws Throwable {
		WebElement fullNameField = regpom.getFullName();
		fullNameField.sendKeys(fullName);
		WebElement emailField = regpom.getEmail();
		emailField.sendKeys(email);
		WebElement phoneField = regpom.getMobileNo();
		phoneField.sendKeys(phone);
		WebElement subjectField = regpom.getSubjectCat();
		subjectField.sendKeys(subject);
		WebElement paperField = regpom.getPaperName();
		paperField.sendKeys(paper);
		WebElement authorscount = regpom.getAuthors();
		authorscount.sendKeys(authors);
		WebElement companyField = regpom.getCompanyName();
		companyField.sendKeys(company);
		WebElement designationField = regpom.getDesignation();
		designationField.sendKeys(designation);
		WebElement gender = regpom.getGender();
		gender.click();
		WebElement city = regpom.getCity();
		city.click();
		WebElement state = regpom.getState();
		state.click();
	}

	@Then("^display 'successfully Registered'$")
	public void display_successfully_Registered() throws Throwable {
		WebElement submitButton = regpom.getConfirmRegButton();
		submitButton.click();
		driver.close();
	}
	
	@When("^User enter invalid details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_enter_invalid_details(String fullName, String email, String phone, String subject, String paper, String authors, String company, String designation) throws Throwable {
		WebElement fullNameField = regpom.getFullName();
		fullNameField.sendKeys(fullName);
		WebElement emailField = regpom.getEmail();
		emailField.sendKeys(email);
		WebElement phoneField = regpom.getMobileNo();
		phoneField.sendKeys(phone);
		WebElement subjectField = regpom.getSubjectCat();
		subjectField.sendKeys(subject);
		WebElement paperField = regpom.getPaperName();
		paperField.sendKeys(paper);
		WebElement authorscount = regpom.getAuthors();
		authorscount.sendKeys(authors);
		WebElement companyField = regpom.getCompanyName();
		companyField.sendKeys(company);
		WebElement designationField = regpom.getDesignation();
		designationField.sendKeys(designation);
		WebElement gender = regpom.getGender();
		gender.click();
		WebElement city = regpom.getCity();
		city.click();
		WebElement state = regpom.getState();
		state.click();
	}

	@Then("^alert box'$")
	public void alert_box() throws Throwable {
		WebElement submitButton = regpom.getConfirmRegButton();
		submitButton.click();
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^User doesnot select city and User enter valid details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_doesnot_select_city_and_User_enter_valid_details(String fullName, String email, String phone, String subject, String paper, String authors, String company, String designation) throws Throwable {
		WebElement fullNameField = regpom.getFullName();
		fullNameField.sendKeys(fullName);
		WebElement emailField = regpom.getEmail();
		emailField.sendKeys(email);
		WebElement phoneField = regpom.getMobileNo();
		phoneField.sendKeys(phone);
		WebElement subjectField = regpom.getSubjectCat();
		subjectField.sendKeys(subject);
		WebElement paperField = regpom.getPaperName();
		paperField.sendKeys(paper);
		WebElement authorscount = regpom.getAuthors();
		authorscount.sendKeys(authors);
		WebElement companyField = regpom.getCompanyName();
		companyField.sendKeys(company);
		WebElement designationField = regpom.getDesignation();
		designationField.sendKeys(designation);
		WebElement gender = regpom.getGender();
		gender.click();
		WebElement city = regpom.getCity();
		
		WebElement state = regpom.getState();
		state.click();
	}

	

	@When("^User doesnot select state and User enter valid details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_doesnot_select_state_and_User_enter_valid_details(String fullName, String email, String phone, String subject, String paper, String authors, String company, String designation) throws Throwable {	    
		WebElement fullNameField = regpom.getFullName();
		fullNameField.sendKeys(fullName);
		WebElement emailField = regpom.getEmail();
		emailField.sendKeys(email);
		WebElement phoneField = regpom.getMobileNo();
		phoneField.sendKeys(phone);
		WebElement subjectField = regpom.getSubjectCat();
		subjectField.sendKeys(subject);
		WebElement paperField = regpom.getPaperName();
		paperField.sendKeys(paper);
		WebElement authorscount = regpom.getAuthors();
		authorscount.sendKeys(authors);
		WebElement companyField = regpom.getCompanyName();
		companyField.sendKeys(company);
		WebElement designationField = regpom.getDesignation();
		designationField.sendKeys(designation);
		WebElement gender = regpom.getGender();
		gender.click();
		WebElement city = regpom.getCity();
		city.click();
		WebElement state = regpom.getState();
		
	}

	

}
