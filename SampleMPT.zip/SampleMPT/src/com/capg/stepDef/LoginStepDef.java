package com.capg.stepDef;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.LoginPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDef {
	
	WebDriver driver;
	LoginPOM pageRepo;

	@Given("^Open any browser and enter login url$")
	public void open_any_browser_and_enter_login_url() throws Throwable {
		
		driver = LoginPOM.getWebDriver();
		String url = "C:\\BDD-workspace-sts\\SampleMPT\\html\\login.html";
		driver.get(url);
		pageRepo = new LoginPOM(driver);
	    
	}

	@When("^User enter valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enter_valid_username_and_valid_password(String userName, String password) throws Throwable {
		WebElement userNameField =  pageRepo.getUserName();
		userNameField.sendKeys(userName);
		WebElement passwordField = pageRepo.getPassword();
		passwordField.sendKeys(password);
	}

	@Then("^Login to registration page$")
	public void enter_valid_details_to_register_and_submit_registration() throws Throwable {
		WebElement loginButton = pageRepo.getLoginButton();
		loginButton.click();
	}

	@When("^User enter invalid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enter_invalid_username_and_valid_password(String userName, String password) throws Throwable {
		WebElement userNameField =  pageRepo.getUserName();
		userNameField.sendKeys(userName);
		WebElement passwordField = pageRepo.getPassword();
		passwordField.sendKeys(password);
		WebElement loginButton = pageRepo.getLoginButton();
		loginButton.click();
	}

	@Then("^display 'Please Enter valid UserName'$")
	public void display_Please_Enter_valid_UserName() throws Throwable {
		String expectedMessage = "* Please enter userName.";
		String actualMessage = pageRepo.getUsernameError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
	}
}
