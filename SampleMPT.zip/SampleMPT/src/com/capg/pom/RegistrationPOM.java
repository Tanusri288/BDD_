package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPOM {
	
	@FindBy(xpath="//*[@id=\"txtFullName\"]")
	@CacheLookup
	WebElement fullName;
	
	@FindBy(xpath="//*[@id=\"txtEmail\"]")
	@CacheLookup
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"txtPhone\"]")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(xpath="//*[@id=\"gender\"]")				//
	@CacheLookup
	WebElement gender;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/select/option[4]")		//
	@CacheLookup
	WebElement city;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select/option[4]")		//
	@CacheLookup
	WebElement state;
	
	@FindBy(xpath="//*[@id=\"txtCardholderName\"]")
	@CacheLookup
	WebElement subjectCat;
	
	@FindBy(xpath="//*[@id=\"txtCvv\"]")				//
	@CacheLookup
	WebElement authors;
	
	@FindBy(xpath="//*[@id=\"txtDebit\"]")
	@CacheLookup
	WebElement paperName;
	
	@FindBy(xpath="//*[@id=\"txtMonth\"]")
	@CacheLookup
	WebElement companyName;
	
	@FindBy(xpath="//*[@id=\"txtYear\"]")
	@CacheLookup
	WebElement designation;
	
	@FindBy(xpath="//*[@id=\"btnPayment\"]")
	@CacheLookup
	WebElement confirmRegButton;
	
	@FindBy(xpath="//*[@id=\"userErrMsg\"]")
	WebElement fullnameError;
	
	public static WebDriver getWebDriver() {
		String path = "C:\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();
		return driver;
	}
	
	public RegistrationPOM(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public WebElement getFullName() {
		return fullName;
	}

	public void setFullName(WebElement fullName) {
		this.fullName = fullName;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(WebElement mobileNo) {
		this.mobileNo = mobileNo;
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(WebElement gender) {
		this.gender = gender;
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(WebElement city) {
		this.city = city;
	}

	public WebElement getState() {
		return state;
	}

	public void setState(WebElement state) {
		this.state = state;
	}

	public WebElement getSubjectCat() {
		return subjectCat;
	}

	public void setSubjectCat(WebElement subjectCat) {
		this.subjectCat = subjectCat;
	}

	public WebElement getAuthors() {
		return authors;
	}

	public void setAuthors(WebElement authors) {
		this.authors = authors;
	}

	public WebElement getPaperName() {
		return paperName;
	}

	public void setPaperName(WebElement paperName) {
		this.paperName = paperName;
	}

	public WebElement getCompanyName() {
		return companyName;
	}

	public void setCompanyName(WebElement companyName) {
		this.companyName = companyName;
	}

	public WebElement getDesignation() {
		return designation;
	}

	public void setDesignation(WebElement designation) {
		this.designation = designation;
	}

	public WebElement getConfirmRegButton() {
		return confirmRegButton;
	}

	public void setConfirmRegButton(WebElement confirmRegButton) {
		this.confirmRegButton = confirmRegButton;
	}

	public WebElement getFullnameError() {
		return fullnameError;
	}

	public void setFullnameError(WebElement fullnameError) {
		this.fullnameError = fullnameError;
	}

	
	
	
}
