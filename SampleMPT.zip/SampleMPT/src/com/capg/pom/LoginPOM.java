package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPOM {
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/table/tbody/tr[2]/td[2]/input")
	@CacheLookup
	WebElement userName;
	
	@FindBy(xpath="//*[@id=\"userErrMsg\"]")
	WebElement usernameError;
	
//	@FindBy(xpath="//*[@id=\"pwdErrMsg\"]")
//	WebElement passwordError;   
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/table/tbody/tr[3]/td[2]/input")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div/form/table/tbody/tr[4]/td[2]/input")
	@CacheLookup
	WebElement loginButton;

	public static WebDriver getWebDriver() {
		String path = "C:\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();
		return driver;
	}
	
	public LoginPOM(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(WebElement userName) {
		this.userName = userName;
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(WebElement password) {
		this.password = password;
	}

	public WebElement getLoginButton() {
		return loginButton;
	}

	public void setLoginButton(WebElement loginButton) {
		this.loginButton = loginButton;
	}

	public WebElement getUsernameError() {
		return usernameError;
	}

	public void setUsernameError(WebElement usernameError) {
		this.usernameError = usernameError;
	}
	
	
}
