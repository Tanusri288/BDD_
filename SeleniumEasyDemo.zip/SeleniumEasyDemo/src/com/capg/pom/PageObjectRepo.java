package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageObjectRepo {
	
	@FindBy()
	@CacheLookup
	WebElement element;
	


	public static WebDriver getWebDriver() {
		String path = "C:\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();
		return driver;
	}
	
	public PageObjectRepo(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	
	
}
