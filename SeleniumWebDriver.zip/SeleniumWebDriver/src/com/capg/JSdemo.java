package com.capg;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class JSdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = WebUtil.getWebDriver();
		String path = "C:\\BDD-workspace-sts\\SeleniumWebDriver\\html\\demo.html";
		String path2 = "https://en.wikipedia.org/wiki/India";
		driver.get(path2);
		
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		
//		jse.executeScript("display()");
		
		jse.executeScript("window.scrollBy(0,800)");
		
//		String sText = jse.executeScript ("return document.getElementById('h1').innerHTML").toString();
//		System.out.println(sText);
	}

}
