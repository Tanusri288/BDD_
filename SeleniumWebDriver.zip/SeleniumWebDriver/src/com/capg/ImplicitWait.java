package com.capg;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ImplicitWait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = WebUtil.getWebDriver();

		 String baseUrl = "http://www.wikipedia.org/";
         driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
         
         driver.get(baseUrl + "/wiki/Main_Page");
         driver.findElement(By.id("searchInput")).clear();
         driver.findElement(By.id("searchInput")).sendKeys("India");
         driver.findElement(By.id("searchButton")).click();

	}

}
