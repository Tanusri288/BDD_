package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MultipleWindows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = WebUtil.getWebDriver();
		String path = "C:\\BDD-workspace-sts\\SeleniumWebDriver\\html\\PopupWin.html";
		driver.get(path);
		String parentWindow = driver.getWindowHandle();
		driver.findElement(By.name("Open")).click();
		driver.switchTo().window("PopupWindow");
		
		driver.findElement(By.name("txtName")).sendKeys("Tanu");
		driver.findElement(By.name("btnAlert")).click();
		driver.switchTo().alert().accept();
		driver.close();								// to close popupwindow
		driver.switchTo().window(parentWindow);
		driver.close();								// to close parent window

	}

}
