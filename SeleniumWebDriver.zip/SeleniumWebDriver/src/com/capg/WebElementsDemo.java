package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebElementsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = WebUtil.getWebDriver();
		String url = "https://www.toolsqa.com/automation-practice-form/";
		driver.navigate().to(url);
//		WebElement element1 = driver.findElement(By.partialLinkText("SELENIUM"));
//		element1.click();
//		driver.navigate().back();
		
		
//		WebElement element2 = driver.findElement(By.linkText("ABOUT"));
//		element2.click();
		

		
//		WebElement gender = driver.findElement(By.id("sex-1"));
//	    gender.click();
		
		
		WebElement element3=driver.findElement(By.xpath("//*[@id='continents']"));		// 	("//select[@name='continents']")
	    Select se1 =new Select(element3);  
	    se1.selectByVisibleText("Africa");
	    
	    
//	    WebElement element4=driver.findElement(By.id("continentsmultiple"));
//	    Select se2 =new Select(element4);  
//	    se2.selectByIndex(2);
	    
	}

}
