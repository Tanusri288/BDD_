package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AlertDemo {

	public static void main(String[] args) {
		WebDriver driver = WebUtil.getWebDriver();
		String path = "C:\\BDD-workspace-sts\\SeleniumWebDriver\\html\\AlertExample.html";
		driver.get(path);
		WebElement element = driver.findElement(By.name("btnAlert"));
//		element.click();

		try {
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.alertIsPresent());
			String alrt = driver.switchTo().alert().getText();
			System.out.print(alrt);
		} catch (Exception ex) {
			System.out.println(ex);
		}

		/* String alertText = driver.switchTo().alert().getText();
		 System.out.println(alertText);
		 driver.switchTo().alert().sendKeys("tanu");
		
		 driver.switchTo().alert().accept();*/
	}
}
