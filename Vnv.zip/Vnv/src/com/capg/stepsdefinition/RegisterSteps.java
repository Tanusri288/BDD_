package com.capg.stepsdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capg.pom.RegisterWebPOM;
import com.capg.pom.WebPOM;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterSteps {
	WebDriver driver;
	@Given("^user is on 'registartion' page$")
	public void user_is_on_registartion_page() throws Throwable {
		driver = RegisterWebPOM.getWebDriver();

		String url = "C:\\BDD-workspace-sts\\Vnv\\html\\registration.html";

		driver.get(url);
	}

	@When("^user enters invalid full name$")
	public void user_enters_invalid_full_name() throws Throwable {
	WebElement namefield =  RegisterWebPOM.getNameField();
	namefield.sendKeys("t");
	WebElement buttonfield =RegisterWebPOM.getButtonField();
	buttonfield.click();
	}

	@Then("^displays 'Please fill the full Name'$")
	public void displays_Please_fill_the_full_Name() throws Throwable {
		String expectedMessage="Please fill the Full Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}


	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
	    WebElement emailField = RegisterWebPOM.getEmailField();
	    emailField.sendKeys("g");
	    WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		String expectedMessage="Please enter valid Email Id.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("521");
		WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}

	@Then("^display 'Please fill Mobile No\\.'$")
	public void display_Please_fill_Mobile_No() throws Throwable {
		String expectedMessage="Please fill the Mobile No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong mobile number$")
    public void user_enters_wrong_mobile_number() throws Throwable {
           WebElement fullName = RegisterWebPOM.getNameField();
           fullName.sendKeys("Tanu");
           WebElement email = RegisterWebPOM.getEmailField();
           email.sendKeys("Tanu@gmail.com");
           WebElement mobileno = RegisterWebPOM.getMobileField();
           mobileno.sendKeys("12345");
           WebElement button = RegisterWebPOM.getButtonField();
           button.click();
    }

 

    @Then("^display 'Please enter valid Mobile Number'$")
    public void display_Please_enter_valid_Mobile_Number() throws Throwable {
         String expectedMessage="Please enter valid Contact no.";
            String actualMessage=driver.switchTo().alert().getText();
            Assert.assertEquals(expectedMessage, actualMessage);
            Thread.sleep(1000);
            driver.switchTo().alert().accept();
            driver.close();
    }
 

	@When("^user does not enter check box$")
	public void user_does_not_enter_check_box() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
		WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}

	@Then("^please enter gender$")
	public void please_enter_gender() throws Throwable {
		
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
	
		WebElement cityField = RegisterWebPOM.getCityField();
		Select select = new Select(cityField);
		select.selectByIndex(0);
		
		WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
	
		WebElement cityField = RegisterWebPOM.getCityField();
		Select select = new Select(cityField);
		select.selectByIndex(1);
		WebElement stateField = RegisterWebPOM.getStateField();
		Select selec = new Select(stateField);
		select.selectByIndex(3);
		WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Subject Category$")
	public void user_enters_invalid_Subject_Category() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
	
		WebElement cityField = RegisterWebPOM.getCityField();
		Select select = new Select(cityField);
		select.selectByIndex(1);
		WebElement stateField = RegisterWebPOM.getStateField();
		Select selec = new Select(stateField);
		selec.selectByIndex(1);
		WebElement subjectField = RegisterWebPOM.getSubjectField();
		subjectField.sendKeys("");
		WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}

	@Then("^displays 'Please fill Subject Category'$")
	public void displays_Please_fill_Subject_Category() throws Throwable {
		String expectedMessage="Please fill the Subject Category";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Paper Name$")
	public void user_enters_invalid_Paper_Name() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
	
		WebElement cityField = RegisterWebPOM.getCityField();
		Select select = new Select(cityField);
		select.selectByIndex(1);
		WebElement stateField = RegisterWebPOM.getStateField();
		Select selec = new Select(stateField);
		selec.selectByIndex(1);
		WebElement subjectField = RegisterWebPOM.getSubjectField();
		subjectField.sendKeys("Capgemini");
		WebElement paperField = RegisterWebPOM.getPaperField();
		paperField.sendKeys("");
		WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	   
	}

	@Then("^displays 'Please fill Paper Name'$")
	public void displays_Please_fill_Paper_Name() throws Throwable {
		String expectedMessage="Please fill the Paper Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid No\\. of Authors$")
	public void user_enters_invalid_No_of_Authors() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
	
		WebElement cityField = RegisterWebPOM.getCityField();
		Select select = new Select(cityField);
		select.selectByIndex(1);
		WebElement stateField = RegisterWebPOM.getStateField();
		Select selec = new Select(stateField);
		selec.selectByIndex(1);
		WebElement subjectField = RegisterWebPOM.getSubjectField();
		subjectField.sendKeys("Capgemini");
		WebElement paperField = RegisterWebPOM.getPaperField();
		paperField.sendKeys("Internal");
		WebElement authorField = RegisterWebPOM.getAuthorField();
		authorField.sendKeys("2");
		WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	   
	}

	@Then("^displays 'Please fill No\\. of Authors'$")
	public void displays_Please_fill_No_of_Authors() throws Throwable {
		String expectedMessage="Pls. fill the authors";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Company Name$")
	public void user_enters_invalid_Company_Name() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
	
		WebElement cityField = RegisterWebPOM.getCityField();
		Select select = new Select(cityField);
		select.selectByIndex(1);
		WebElement stateField = RegisterWebPOM.getStateField();
		Select selec = new Select(stateField);
		selec.selectByIndex(1);
		WebElement subjectField = RegisterWebPOM.getSubjectField();
		subjectField.sendKeys("Capgemini");
		WebElement paperField = RegisterWebPOM.getPaperField();
		paperField.sendKeys("Internal");
		WebElement authorField = RegisterWebPOM.getAuthorField();
		authorField.sendKeys("2");
		
	   WebElement companyField = RegisterWebPOM.getCompanyField();
	   companyField.sendKeys("");
	   WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}

	@Then("^displays 'Please fill Company Name'$")
	public void displays_Please_fill_Company_Name() throws Throwable {
		String expectedMessage="Please fill Company Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Designation$")
	public void user_enters_invalid_Designation() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
	
		WebElement cityField = RegisterWebPOM.getCityField();
		Select select = new Select(cityField);
		select.selectByIndex(1);
		WebElement stateField = RegisterWebPOM.getStateField();
		Select selec = new Select(stateField);
		selec.selectByIndex(1);
		WebElement subjectField = RegisterWebPOM.getSubjectField();
		subjectField.sendKeys("Capgemini");
		WebElement paperField = RegisterWebPOM.getPaperField();
		paperField.sendKeys("Internal");
		WebElement authorField = RegisterWebPOM.getAuthorField();
		authorField.sendKeys("2");
		
	   WebElement companyField = RegisterWebPOM.getCompanyField();
	   companyField.sendKeys("TCS");
	   WebElement designationField= RegisterWebPOM.getDesignationField();
		  designationField.sendKeys("");
	   WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}

	@Then("^displays 'Please fill Designation'$")
	public void displays_Please_fill_Designation() throws Throwable {
		String expectedMessage="Please fill Designation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
		WebElement namefield=RegisterWebPOM.getNameField();
		namefield.sendKeys("Tanu");
		WebElement emaiField = RegisterWebPOM.getEmailField();
		emaiField.sendKeys("Tanu@gmail.com");
		WebElement mobileField = RegisterWebPOM.getMobileField();
		mobileField.sendKeys("9010622980");
		WebElement checkField = RegisterWebPOM.getGenderField();
		checkField.click();
	
		WebElement cityField = RegisterWebPOM.getCityField();
		Select select = new Select(cityField);
		select.selectByIndex(1);
		WebElement stateField = RegisterWebPOM.getStateField();
		Select selec = new Select(stateField);
		selec.selectByIndex(1);
		WebElement subjectField = RegisterWebPOM.getSubjectField();
		subjectField.sendKeys("Capgemini");
		WebElement paperField = RegisterWebPOM.getPaperField();
		paperField.sendKeys("Internal");
		WebElement authorField = RegisterWebPOM.getAuthorField();
		authorField.sendKeys("2");
		
	   WebElement companyField = RegisterWebPOM.getCompanyField();
	   companyField.sendKeys("Capgemini");
	  WebElement designationField= RegisterWebPOM.getDesignationField();
	  designationField.sendKeys("Analyst");
	   WebElement buttonfield =RegisterWebPOM.getButtonField();
		buttonfield.click();
	}
	

	@Then("^displays 'registartion Completed!!!'$")
	public void displays_registartion_Completed() throws Throwable {
		driver.get("C:\\BDD1\\Vnv\\html\\success.html");
		//driver.close();
	}
}
