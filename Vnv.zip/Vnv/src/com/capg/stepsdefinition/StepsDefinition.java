package com.capg.stepsdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.WebPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinition {
	WebDriver driver;

@Given("^Open any browser and enter the url$")
public void open_any_browser_and_enter_the_url() throws Throwable {
	driver = WebPOM.getWebDriver();

	String url = "C:\\BDD-workspace-sts\\Vnv\\html\\login.html";

	driver.get(url);
}

@When("^user enter valid username \"([^\"]*)\" and password \"([^\"]*)\"$")
public void user_enter_valid_username_and_password(String username, String password) throws Throwable {
	WebElement userField =	WebPOM.getUserField();
	   userField.sendKeys(username);
	   WebElement passwordField =	WebPOM.getPasswordField();
	   passwordField.sendKeys(password);
}

@Then("^Login to International Journal Portal$")
public void login_to_International_Journal_Portal() throws Throwable {
	WebElement loginButton = WebPOM.getLoginButton();

	loginButton.click();
	driver.close();

   
}

@When("^user enter invalid username \"([^\"]*)\" and invalid password \"([^\"]*)\"$")
public void user_enter_invalid_username_and_invalid_password(String username, String password) throws Throwable {
	WebElement userField =	WebPOM.getUserField();
	   userField.sendKeys(username);
	   WebElement passwordField =	WebPOM.getPasswordField();
	   passwordField.sendKeys(password);
}

@Then("^Display please enter valid credentials$")
public void display_please_enter_valid_credentials() throws Throwable {
	WebElement loginButton = WebPOM.getLoginButton();

	loginButton.click();
	driver.switchTo().alert().accept();
	driver.close();
}

@When("^user enter valid username \"([^\"]*)\" and invalid password \"([^\"]*)\"$")
public void user_enter_valid_username_and_invalid_password(String username, String password) throws Throwable {
	WebElement userField =	WebPOM.getUserField();
	   userField.sendKeys(username);
	   WebElement passwordField =	WebPOM.getPasswordField();
	   passwordField.sendKeys(password);
   
}

@Then("^Display please enter valid password$")
public void display_please_enter_valid_password() throws Throwable {
	WebElement loginButton = WebPOM.getLoginButton();

	loginButton.click();
	driver.switchTo().alert().accept();
	driver.close();
}

@When("^user enter invalid username \"([^\"]*)\" and  valid password \"([^\"]*)\"$")
public void user_enter_invalid_username_and_valid_password(String username, String password) throws Throwable {
	WebElement userField =	WebPOM.getUserField();
	   userField.sendKeys(username);
	   WebElement passwordField =	WebPOM.getPasswordField();
	   passwordField.sendKeys(password);
}

@Then("^Display please enter valid username$")
public void display_please_enter_valid_username() throws Throwable {
	WebElement loginButton = WebPOM.getLoginButton();

	loginButton.click();
	driver.switchTo().alert().accept();
	driver.close();
}


	
}
