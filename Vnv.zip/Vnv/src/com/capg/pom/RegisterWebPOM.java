package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

public class RegisterWebPOM {
	static WebDriver driver;

	public static WebDriver getWebDriver() {
		driver = WebUtil.getWebDriver();
		return driver;
	}

	public static WebElement getNameField() {

		return driver.findElement(By.id("txtFullName"));

	}

	public static WebElement getEmailField() {

		return driver.findElement(By.id("txtEmail"));

	}
	public static WebElement getGenderField() {
		return driver.findElement(By.xpath("//*[@id=\"gender\"]"));
	}
	
	
	
	public static WebElement getMobileField() {

		return driver.findElement(By.id("txtPhone"));
	}
	
	
	public static WebElement getCityField() {
		return driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/select"));
	}
	

	public static WebElement getStateField() {
		return driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[7]/td[2]/select"));
	}
	public static WebElement getSubjectField() {
		return driver.findElement(By.id("txtCardholderName"));
	}
	
	public static WebElement getPaperField() {
		return driver.findElement(By.id("txtDebit"));
	}
	public static WebElement getAuthorField() {
		return driver.findElement(By.id("txtCvv"));
	}
	public static WebElement getCompanyField() {
		return driver.findElement(By.id("txtMonth"));
	}
	public static WebElement getDesignationField() {
		return driver.findElement(By.id("txtYear"));
	}
	
	public static WebElement getButtonField() {

		return driver.findElement(By.id("btnPayment"));
}
}