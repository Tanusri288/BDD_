$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/BDD-workspace-sts/BDD_Tags/src/login.feature");
formatter.feature({
  "line": 3,
  "name": "Multiple Scenario Testing",
  "description": "",
  "id": "multiple-scenario-testing",
  "keyword": "Feature",
  "tags": [
    {
      "line": 2,
      "name": "@Test"
    }
  ]
});
formatter.scenario({
  "line": 6,
  "name": "Login Icompass with valid credentials",
  "description": "",
  "id": "multiple-scenario-testing;login-icompass-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "Navigate to Icompass URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "Enter valid username \"gtanusri\" and valid password \"tanU@5678\"",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "Login Successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.navigate_to_Icompass_URL()"
});
formatter.result({
  "duration": 9029845100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "gtanusri",
      "offset": 22
    },
    {
      "val": "tanU@5678",
      "offset": 52
    }
  ],
  "location": "StepDefinition.enter_valid_username_and_valid_password(String,String)"
});
formatter.result({
  "duration": 210017500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.login_Successfully()"
});
formatter.result({
  "duration": 260100100,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Display climate details",
  "description": "",
  "id": "multiple-scenario-testing;display-climate-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 16,
  "name": "Navigate to Google URL",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "Enter input \"chennai climate\"",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "Climate details display",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.navigate_to_Google_URL()"
});
formatter.result({
  "duration": 6707045900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "chennai climate",
      "offset": 13
    }
  ],
  "location": "StepDefinition.enter_input(String)"
});
formatter.result({
  "duration": 3111128600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.climate_details_display()"
});
formatter.result({
  "duration": 2326279400,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Display google images page",
  "description": "",
  "id": "multiple-scenario-testing;display-google-images-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "Navigate to Google URL",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "click on image link",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "Display images page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.navigate_to_Google_URL()"
});
formatter.result({
  "duration": 6969934300,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.click_on_image_link()"
});
formatter.result({
  "duration": 852878500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.display_images_page()"
});
formatter.result({
  "duration": 204503700,
  "status": "passed"
});
});