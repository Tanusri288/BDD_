package com.capg_.StepDef;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg_.WebUtil;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	WebDriver driver;
	
	@Given("^Navigate to Icompass URL$")
	public void navigate_to_Icompass_URL() throws Throwable {
		driver = WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com/iCompass/#/";
		driver.get(url);
	}

	@When("^User enter login credentials username$")
	public void user_enter_login_credentials_username(DataTable data) throws Throwable {
		List<List<String>> table = data.raw();
		WebElement userTextField = driver.findElement(By.id("userName"));
		WebElement passwordTextField = driver.findElement(By.id("password"));
		String username = table.get(0).get(0);
		String password = table.get(0).get(1);
		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);
	}

	@Then("^Validation should be performed$")
	public void validation_should_be_performed() throws Throwable {
		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();
//		driver.close();
	}
}



